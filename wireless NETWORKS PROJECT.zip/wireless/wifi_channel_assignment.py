import random
import math
import matplotlib.pyplot as plt
import copy

# FIX RANDOMNESS
random.seed(42)

# ---------------- NETWORK SETTINGS ----------------
num_aps = 15
area_size = 30

# Create Access Points
aps = []

for i in range(num_aps):
    aps.append({
        "id": i,
        "x": random.uniform(0, area_size),
        "y": random.uniform(0, area_size),
        "channel": None
    })

# ---------------- DISTANCE FUNCTION ----------------
def distance(a, b):
    return math.sqrt((a["x"] - b["x"])**2 + (a["y"] - b["y"])**2)

# ---------------- INTERFERENCE FUNCTION ----------------
def calculate_interference(aps):

    interference = 0

    for i in range(len(aps)):
        for j in range(i + 1, len(aps)):

            # Same channel check
            if aps[i]["channel"] == aps[j]["channel"]:

                d = distance(aps[i], aps[j])

                # Distance threshold
                if d < 8:
                    interference += 1

    return interference

# Available Wi-Fi channels
channels = [1, 6, 11]

# =====================================================
# STATIC CHANNEL ASSIGNMENT
# =====================================================

aps_static = copy.deepcopy(aps)

for i, ap in enumerate(aps_static):
    ap["channel"] = channels[i % 3]

interference_static = calculate_interference(aps_static)

# =====================================================
# DYNAMIC CHANNEL ASSIGNMENT
# =====================================================

aps_dynamic = copy.deepcopy(aps)

for ap in aps_dynamic:

    best_channel = None
    minimum_interference = float('inf')

    for ch in channels:

        ap["channel"] = ch

        current_interference = calculate_interference(aps_dynamic)

        if current_interference < minimum_interference:

            minimum_interference = current_interference
            best_channel = ch

    ap["channel"] = best_channel

interference_dynamic = calculate_interference(aps_dynamic)

# =====================================================
# PERFORMANCE METRICS
# =====================================================

packets_sent = 100

# Packet loss depends on interference
packet_loss_static = interference_static * 5
packet_loss_dynamic = interference_dynamic * 5

# Delivered packets
packets_delivered_static = packets_sent - packet_loss_static
packets_delivered_dynamic = packets_sent - packet_loss_dynamic

# PDR
pdr_static = (packets_delivered_static / packets_sent) * 100
pdr_dynamic = (packets_delivered_dynamic / packets_sent) * 100

# Throughput
throughput_static = packets_delivered_static
throughput_dynamic = packets_delivered_dynamic

# =====================================================
# VISUALIZATION
# =====================================================

colors = {
    1: 'red',
    6: 'green',
    11: 'blue'
}

channel_labels = {
    1: 'Channel 1',
    6: 'Channel 6',
    11: 'Channel 11'
}

# Create ONE WINDOW with 3 graphs
fig, axes = plt.subplots(1, 3, figsize=(20, 6))

# =====================================================
# STATIC GRAPH
# =====================================================

axes[0].set_title(
    f"Static Assignment\nInterference = {interference_static}",
    fontsize=13
)

for ap in aps_static:

    axes[0].scatter(
        ap["x"],
        ap["y"],
        color=colors[ap["channel"]],
        s=150,
        edgecolors='black'
    )

    axes[0].text(
        ap["x"] + 0.3,
        ap["y"] + 0.3,
        f'AP{ap["id"]}',
        fontsize=8
    )

# Interference lines
for i in range(len(aps_static)):
    for j in range(i + 1, len(aps_static)):

        if aps_static[i]["channel"] == aps_static[j]["channel"]:

            d = distance(aps_static[i], aps_static[j])

            if d < 8:

                axes[0].plot(
                    [aps_static[i]["x"], aps_static[j]["x"]],
                    [aps_static[i]["y"], aps_static[j]["y"]],
                    'r--',
                    linewidth=1
                )

                # Distance label
                mid_x = (aps_static[i]["x"] + aps_static[j]["x"]) / 2
                mid_y = (aps_static[i]["y"] + aps_static[j]["y"]) / 2

                axes[0].text(
                    mid_x,
                    mid_y,
                    f'{d:.1f}',
                    fontsize=7
                )

# Legend
for ch in channels:
    axes[0].scatter(
        [],
        [],
        color=colors[ch],
        label=channel_labels[ch]
    )

axes[0].legend(title="Wi-Fi Channels")

# =====================================================
# DYNAMIC GRAPH
# =====================================================

axes[1].set_title(
    f"Dynamic Assignment\nInterference = {interference_dynamic}",
    fontsize=13
)

for ap in aps_dynamic:

    axes[1].scatter(
        ap["x"],
        ap["y"],
        color=colors[ap["channel"]],
        s=150,
        edgecolors='black'
    )

    axes[1].text(
        ap["x"] + 0.3,
        ap["y"] + 0.3,
        f'AP{ap["id"]}',
        fontsize=8
    )

# Interference lines
for i in range(len(aps_dynamic)):
    for j in range(i + 1, len(aps_dynamic)):

        if aps_dynamic[i]["channel"] == aps_dynamic[j]["channel"]:

            d = distance(aps_dynamic[i], aps_dynamic[j])

            if d < 8:

                axes[1].plot(
                    [aps_dynamic[i]["x"], aps_dynamic[j]["x"]],
                    [aps_dynamic[i]["y"], aps_dynamic[j]["y"]],
                    'r--',
                    linewidth=1
                )

                # Distance label
                mid_x = (aps_dynamic[i]["x"] + aps_dynamic[j]["x"]) / 2
                mid_y = (aps_dynamic[i]["y"] + aps_dynamic[j]["y"]) / 2

                axes[1].text(
                    mid_x,
                    mid_y,
                    f'{d:.1f}',
                    fontsize=7
                )

# Legend
for ch in channels:
    axes[1].scatter(
        [],
        [],
        color=colors[ch],
        label=channel_labels[ch]
    )

axes[1].legend(title="Wi-Fi Channels")

# =====================================================
# PERFORMANCE COMPARISON BAR CHART
# =====================================================

metrics = ['Interference', 'PDR', 'Throughput']

static_values = [
    interference_static,
    pdr_static,
    throughput_static
]

dynamic_values = [
    interference_dynamic,
    pdr_dynamic,
    throughput_dynamic
]

x = range(len(metrics))

axes[2].bar(
    x,
    static_values,
    width=0.4,
    label='Static'
)

axes[2].bar(
    [i + 0.4 for i in x],
    dynamic_values,
    width=0.4,
    label='Dynamic'
)

axes[2].set_xticks([i + 0.2 for i in x])
axes[2].set_xticklabels(metrics)

axes[2].set_title("Performance Comparison", fontsize=13)
axes[2].set_ylabel("Values")
axes[2].legend()

# =====================================================
# FINAL STYLING
# =====================================================

for ax in axes[:2]:
    ax.set_xlabel("X Position")
    ax.set_ylabel("Y Position")
    ax.grid(alpha=0.3)

plt.tight_layout()
plt.show()

# =====================================================
# TERMINAL RESULTS
# =====================================================

print("\n========== FINAL RESULTS ==========")

print("\nSTATIC ASSIGNMENT")
print(f"Interference : {interference_static}")
print(f"PDR          : {pdr_static:.2f}%")
print(f"Throughput   : {throughput_static}")

print("\nDYNAMIC ASSIGNMENT")
print(f"Interference : {interference_dynamic}")
print(f"PDR          : {pdr_dynamic:.2f}%")
print(f"Throughput   : {throughput_dynamic}")