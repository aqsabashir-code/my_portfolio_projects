import {
  auth,
  db,
  collection,
  addDoc,
  onSnapshot,
  query,
  orderBy,
  serverTimestamp,
  deleteDoc,
  doc
} from "./firebase.js";

const questionInput = document.getElementById("questionInput");
const postBtn = document.getElementById("postBtn");
const questionsContainer = document.getElementById("questionsContainer");

/* ---------- NOTIFICATION ---------- */
function showNotification(msg, type = "info") {
  let box = document.getElementById("notifyBox");
  if (!box) {
    box = document.createElement("div");
    box.id = "notifyBox";
    document.body.appendChild(box);
  }

  const n = document.createElement("div");
  n.className = `notify ${type}`;
  n.textContent = msg;
  box.appendChild(n);

  setTimeout(() => n.remove(), 3000);
}

/* ---------- POST QUESTION ---------- */
postBtn.addEventListener("click", async () => {
  const text = questionInput.value.trim();
  if (!text) return showNotification("Write a question first", "warn");

  const user = auth.currentUser;
  if (!user) return showNotification("Login required", "error");

  await addDoc(collection(db, "questions"), {
    text,
    createdBy: {
      uid: user.uid,
      name: user.displayName || "Student"
    },
    createdAt: serverTimestamp()
  });

  questionInput.value = "";
  showNotification("Question posted ✅");
});

/* ---------- LOAD QUESTIONS ---------- */
const q = query(collection(db, "questions"), orderBy("createdAt", "desc"));

onSnapshot(q, snapshot => {
  questionsContainer.innerHTML = "";
  const user = auth.currentUser;

  snapshot.forEach(docSnap => {
    const qid = docSnap.id;
    const qdata = docSnap.data();

    const card = document.createElement("div");
    card.className = "card question";
    card.innerHTML = `
      <h4>${qdata.text}</h4>
      <p class="meta">Asked by ${qdata.createdBy.name}</p>

      <div class="answers" id="answers_${qid}"></div>

      <div class="q-actions">
        <button class="replyBtn">Reply</button>
        <button class="reportBtn">Report</button>
        ${
          user && user.uid === qdata.createdBy.uid
            ? `<button class="deleteBtn danger">Delete</button>`
            : ""
        }
      </div>
    `;

    /* ---------- DELETE QUESTION ---------- */
    const delBtn = card.querySelector(".deleteBtn");
    if (delBtn) {
      delBtn.onclick = async () => {
        if (!confirm("Delete this question?")) return;
        await deleteDoc(doc(db, "questions", qid));
        showNotification("Question deleted 🗑", "warn");
      };
    }

    /* ---------- REPLY (NO BOX, PROMPT) ---------- */
    card.querySelector(".replyBtn").onclick = async () => {
      if (!user) return showNotification("Login required", "error");

      const answer = prompt("Write your reply:");
      if (!answer || !answer.trim()) return;

      await addDoc(collection(db, `questions/${qid}/answers`), {
        text: answer.trim(),
        createdBy: {
          uid: user.uid,
          name: user.displayName || "Student"
        },
        createdAt: serverTimestamp()
      });

      showNotification("Reply added 👍");
    };

    /* ---------- REPORT (NO BOX, PROMPT) ---------- */
    card.querySelector(".reportBtn").onclick = async () => {
      if (!user) return showNotification("Login required", "error");

      const reason = prompt("Reason for reporting:");
      if (!reason || !reason.trim()) return;

      await addDoc(collection(db, "reports"), {
        type: "question",
        questionId: qid,
        questionText: qdata.text,
        reportedUserId: qdata.createdBy.uid,
        reportedUserName: qdata.createdBy.name,
        reportedBy: user.uid,
        reason: reason.trim(),
        createdAt: serverTimestamp()
      });

      showNotification("Reported 🚩", "warn");
    };

    questionsContainer.appendChild(card);

    /* ---------- LOAD ANSWERS ---------- */
    const answersDiv = card.querySelector(`#answers_${qid}`);
    const aq = query(
      collection(db, `questions/${qid}/answers`),
      orderBy("createdAt", "asc")
    );

    onSnapshot(aq, snap => {
      answersDiv.innerHTML = "";
      snap.forEach(aSnap => {
        const ans = aSnap.data();
        const ansId = aSnap.id;

        const div = document.createElement("div");
        div.className = "answer";
        div.innerHTML = `
          <p>${ans.text}</p>
          <small>— ${ans.createdBy.name}</small>
          ${
            user && user.uid === ans.createdBy.uid
              ? `<button class="danger delAns">Delete</button>`
              : ""
          }
        `;

        const delAns = div.querySelector(".delAns");
        if (delAns) {
          delAns.onclick = async () => {
            if (!confirm("Delete this answer?")) return;
            await deleteDoc(doc(db, `questions/${qid}/answers`, ansId));
            showNotification("Answer deleted 🗑", "warn");
          };
        }

        answersDiv.appendChild(div);
      });
    });
  });
});
