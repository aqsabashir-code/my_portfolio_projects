import { auth, db } from "./firebase.js";
import { 
  createUserWithEmailAndPassword, 
  updateProfile 
} from "https://www.gstatic.com/firebasejs/11.1.0/firebase-auth.js";
import {
  doc,
  setDoc
} from "https://www.gstatic.com/firebasejs/11.1.0/firebase-firestore.js";

document.getElementById("signupForm").addEventListener("submit", async (e) => {
    e.preventDefault();

    const name = document.getElementById("name").value;
    const roll = document.getElementById("roll").value;
    const dept = document.getElementById("department").value;
    const email = document.getElementById("email").value;
    const pass = document.getElementById("password").value;

    try {
        // Create user in Firebase Auth
        const userCred = await createUserWithEmailAndPassword(auth, email, pass);

        // Update Firebase Auth profile name
        await updateProfile(userCred.user, { displayName: name });

        // Save extra student info in Firestore database
        await setDoc(doc(db, "users", userCred.user.uid), {
            name: name,
            roll: roll,
            department: dept,
            email: email
        });

        alert("Signup successful!");
        window.location.href = "home.html";
    } catch (error) {
        alert(error.message);
    }
});
