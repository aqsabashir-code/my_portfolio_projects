import { auth } from "./firebase.js";
import { onAuthStateChanged } from "https://www.gstatic.com/firebasejs/11.1.0/firebase-auth.js";

// DOM
const notesList = document.getElementById("notesList");
const searchInput = document.getElementById("searchInput");

let currentUserUid = null;

// Helper to get all notes from all users
function getAllNotes() {
  const notes = [];
  for (let i = 0; i < localStorage.length; i++) {
    const key = localStorage.key(i);
    if (key.startsWith("notes_")) {
      const userUid = key.split("_")[1];
      const userNotes = JSON.parse(localStorage.getItem(key)) || [];
      userNotes.forEach((note, index) => {
        notes.push({
          ...note,
          ownerUid: userUid,
          noteIndex: index
        });
      });
    }
  }
  return notes.sort((a, b) => a.name.localeCompare(b.name));
}

// Generate rating key per note
function noteRatingKey(ownerUid, noteIndex) {
  return `noteRating_${ownerUid}_${noteIndex}`;
}

// Update note rating UI
function updateNoteRatingUI(avg, container) {
  const percentText = container.querySelector(".note-rating-percent");
  percentText.textContent = Math.round(avg * 20) + "%";

  const starEls = container.querySelectorAll("i");
  starEls.forEach((star, index) => {
    if (index < Math.round(avg)) {
      star.classList.add("fa-solid");
      star.classList.remove("fa-regular");
    } else {
      star.classList.remove("fa-solid");
      star.classList.add("fa-regular");
    }
  });
}

// Render notes
function renderNotes(filter = "") {
  const notes = getAllNotes();
  notesList.innerHTML = "";

  notes
    .filter(note => note.name.toLowerCase().includes(filter.toLowerCase()) || (note.subject && note.subject.toLowerCase().includes(filter.toLowerCase())))
    .forEach(note => {
      const li = document.createElement("li");
      li.className = "note-item";

      // **Uploader profile pic**
      const profileImg = document.createElement("img");
      profileImg.className = "uploader-pic";
      const savedPhoto = localStorage.getItem(`profilePhoto_${note.ownerUid}`);
      profileImg.src = savedPhoto ? savedPhoto : "student.jpg";
      li.appendChild(profileImg);

      // File icon
      const fileIcon = document.createElement("i");
      if (note.name.endsWith(".pdf")) fileIcon.className = "fa-solid fa-file-pdf file-icon";
      else if (note.name.endsWith(".doc") || note.name.endsWith(".docx")) fileIcon.className = "fa-solid fa-file-word file-icon";
      else if (note.name.endsWith(".mp4")) fileIcon.className = "fa-solid fa-video file-icon";
      else fileIcon.className = "fa-solid fa-file file-icon";
      li.appendChild(fileIcon);

      // Details
      const details = document.createElement("div");
      details.className = "note-details";

      const h3 = document.createElement("h3");
      h3.textContent = note.name;
      details.appendChild(h3);

      const p = document.createElement("p");
      p.innerHTML = `Uploaded by <strong>${note.ownerUid === currentUserUid ? "You" : "Student " + note.ownerUid}</strong>`;
      details.appendChild(p);

      li.appendChild(details);

      // Rating container
      const ratingContainer = document.createElement("div");
      ratingContainer.className = "rating";

      const percentText = document.createElement("span");
      percentText.className = "note-rating-percent";
      percentText.style.marginRight = "5px";
      ratingContainer.appendChild(percentText);

      for (let i = 1; i <= 5; i++) {
        const star = document.createElement("i");
        star.classList.add("fa-regular", "fa-star");
        star.dataset.value = i;

        // Only allow rating if not own note
        if (note.ownerUid !== currentUserUid) {
          star.style.cursor = "pointer";
          star.addEventListener("click", () => {
            const key = noteRatingKey(note.ownerUid, note.noteIndex);
            const saved = JSON.parse(localStorage.getItem(key)) || { total: 0, count: 0 };
            saved.total += i;
            saved.count += 1;
            localStorage.setItem(key, JSON.stringify(saved));
            updateNoteRatingUI(saved.total / saved.count, ratingContainer);
            alert("Rating submitted!");
          });
        } else {
          star.style.pointerEvents = "none";
          star.style.opacity = "0.4";
        }

        ratingContainer.appendChild(star);
      }

      // Load saved rating
      const key = noteRatingKey(note.ownerUid, note.noteIndex);
      const saved = JSON.parse(localStorage.getItem(key)) || { total: 0, count: 0 };
      const avg = saved.count === 0 ? 0 : saved.total / saved.count;
      updateNoteRatingUI(avg, ratingContainer);

      li.appendChild(ratingContainer);

      // Download
      const dl = document.createElement("a");
      dl.href = note.data;
      dl.download = note.name;
      dl.textContent = "Download";
      dl.className = "btn small";
      dl.style.marginLeft = "10px";
      li.appendChild(dl);

      notesList.appendChild(li);
    });

  notesList.style.maxHeight = "400px";
  notesList.style.overflowY = "auto";
}

// Search filter
searchInput.addEventListener("keyup", () => {
  renderNotes(searchInput.value);
});

// Auth load
onAuthStateChanged(auth, user => {
  if (!user) {
    window.location.href = "index.html";
    return;
  }
  currentUserUid = user.uid;
  renderNotes();
});
