import { auth } from "./firebase.js";
import { onAuthStateChanged } from "https://www.gstatic.com/firebasejs/11.1.0/firebase-auth.js";

// DOM elements
const profileImg = document.getElementById("profilePhoto");
const photoInput = document.getElementById("profilePhotoInput");
const uploadBtn = document.getElementById("uploadProfileBtn");
const deleteBtn = document.getElementById("deleteProfileBtn");
const stars = document.querySelectorAll("#ratingStars i");
const percentText = document.getElementById("ratingPercent");

const uploadForm = document.getElementById("uploadForm");
const fileInput = document.getElementById("fileUpload");
const notesList = document.getElementById("notesList");

// Hide file input
photoInput.style.display = "none";
uploadBtn.addEventListener("click", () => photoInput.click());

// Global variables
let currentUserUid = null;
let noteOwnerUid = null;

// Rating keys
function ratingKey() {
  return `rating_for_${noteOwnerUid}`;
}
function noteRatingKey(noteIndex) {
  return `noteRating_${noteOwnerUid}_${noteIndex}`;
}
function notesKey() {
  return `notes_${noteOwnerUid}`;
}

// ===== PROFILE PHOTO =====
photoInput.addEventListener("change", () => {
  const file = photoInput.files[0];
  if (!file) return;
  const user = auth.currentUser;
  if (!user) return;

  const reader = new FileReader();
  reader.onload = () => {
    localStorage.setItem(`profilePhoto_${user.uid}`, reader.result);
    profileImg.src = reader.result;
    alert("Profile photo saved successfully!");
  };
  reader.readAsDataURL(file);
});

deleteBtn.addEventListener("click", () => {
  const user = auth.currentUser;
  if (!user) return;
  if (!confirm("Are you sure you want to delete your profile photo?")) return;

  localStorage.removeItem(`profilePhoto_${user.uid}`);
  profileImg.src = "student.jpg";
  alert("Profile photo deleted successfully!");
});

// ===== DASHBOARD RATING SYSTEM (overall student rating) =====
function updateRatingUI(avg) {
  percentText.textContent = Math.round(avg * 20) + "%";
  stars.forEach((star, index) => {
    if (index < Math.round(avg)) {
      star.classList.add("fa-solid");
      star.classList.remove("fa-regular");
    } else {
      star.classList.remove("fa-solid");
      star.classList.add("fa-regular");
    }
  });
}

function loadRating() {
  if (!noteOwnerUid) return;
  const saved = JSON.parse(localStorage.getItem(ratingKey())) || { total: 0, count: 0 };
  const avg = saved.count === 0 ? 0 : saved.total / saved.count;
  updateRatingUI(avg);
}

function setRatingPermission() {
  if (currentUserUid === noteOwnerUid) {
    stars.forEach(star => {
      star.style.pointerEvents = "none";
      star.style.opacity = "0.4";
    });
    percentText.title = "You cannot rate your own notes";
  } else {
    stars.forEach(star => {
      star.style.pointerEvents = "auto";
      star.style.opacity = "1";
    });
    percentText.title = "";
  }
}

stars.forEach(star => {
  star.addEventListener("click", () => {
    if (currentUserUid === noteOwnerUid) return;
    const value = Number(star.dataset.value);
    const saved = JSON.parse(localStorage.getItem(ratingKey())) || { total: 0, count: 0 };
    saved.total += value;
    saved.count += 1;
    localStorage.setItem(ratingKey(), JSON.stringify(saved));
    const avg = saved.total / saved.count;
    updateRatingUI(avg);
    alert("Rating submitted successfully!");
  });
});

// ===== NOTES SYSTEM =====
function loadNotes() {
  const notes = JSON.parse(localStorage.getItem(notesKey())) || [];
  notesList.innerHTML = "";

  notes.forEach((note, index) => {
    const li = document.createElement("li");
    li.style.display = "flex";
    li.style.justifyContent = "space-between";
    li.style.alignItems = "center";
    li.style.marginBottom = "5px";

    // Note title
    const span = document.createElement("span");
    span.textContent = note.name;
    li.appendChild(span);

    // Actions container
    const actions = document.createElement("div");
    actions.style.display = "flex";
    actions.style.alignItems = "center";

    // Download
    const dlBtn = document.createElement("a");
    dlBtn.href = note.data;
    dlBtn.download = note.name;
    dlBtn.textContent = "Download";
    dlBtn.style.marginLeft = "10px";
    actions.appendChild(dlBtn);

    // Delete (only for owner)
    if (currentUserUid === noteOwnerUid) {
      const delBtn = document.createElement("button");
      delBtn.textContent = "Delete";
      delBtn.style.marginLeft = "10px";
      delBtn.addEventListener("click", () => deleteNote(index));
      actions.appendChild(delBtn);
    }

    // Per-note rating
    const starContainer = document.createElement("div");
    starContainer.style.display = "flex";
    starContainer.style.alignItems = "center";
    starContainer.style.marginLeft = "10px";

    const percentText = document.createElement("span");
    percentText.className = "note-rating-percent";
    percentText.style.marginRight = "5px";
    starContainer.appendChild(percentText);

    for (let i = 1; i <= 5; i++) {
      const star = document.createElement("i");
      star.classList.add("fa-regular", "fa-star");
      star.dataset.value = i;

      if (currentUserUid !== noteOwnerUid) {
        star.style.cursor = "pointer";
        star.addEventListener("click", () => {
          const key = noteRatingKey(index);
          const saved = JSON.parse(localStorage.getItem(key)) || { total: 0, count: 0 };
          saved.total += i;
          saved.count += 1;
          localStorage.setItem(key, JSON.stringify(saved));
          updateNoteRatingUI(saved.total / saved.count, starContainer);
          alert("Rating submitted!");
        });
      } else {
        star.style.pointerEvents = "none";
        star.style.opacity = "0.4";
      }

      starContainer.appendChild(star);
    }

    const key = noteRatingKey(index);
    const saved = JSON.parse(localStorage.getItem(key)) || { total: 0, count: 0 };
    const avg = saved.count === 0 ? 0 : saved.total / saved.count;
    updateNoteRatingUI(avg, starContainer);

    actions.appendChild(starContainer);
    li.appendChild(actions);
    notesList.appendChild(li);
  });

  notesList.style.maxHeight = "200px";
  notesList.style.overflowY = "auto";
}

function updateNoteRatingUI(avg, container) {
  const percentText = container.querySelector(".note-rating-percent");
  percentText.textContent = Math.round(avg * 20) + "%";
  const starEls = container.querySelectorAll("i");
  starEls.forEach((star, index) => {
    if (index < Math.round(avg)) {
      star.classList.add("fa-solid");
      star.classList.remove("fa-regular");
    } else {
      star.classList.remove("fa-solid");
      star.classList.add("fa-regular");
    }
  });
}

function deleteNote(index) {
  const notes = JSON.parse(localStorage.getItem(notesKey())) || [];
  notes.splice(index, 1);
  localStorage.setItem(notesKey(), JSON.stringify(notes));
  loadNotes();
  alert("Note deleted successfully!");
}

uploadForm.addEventListener("submit", e => {
  e.preventDefault();
  const file = fileInput.files[0];
  if (!file) return alert("Please select a file.");

  const notes = JSON.parse(localStorage.getItem(notesKey())) || [];
  const reader = new FileReader();
  reader.onload = () => {
    notes.push({ name: file.name, data: reader.result });
    localStorage.setItem(notesKey(), JSON.stringify(notes));
    loadNotes();
    fileInput.value = "";
    alert("Note uploaded successfully!");
  };
  reader.readAsDataURL(file);
});

// ===== ON AUTH LOAD =====
onAuthStateChanged(auth, (user) => {
  if (!user) {
    window.location.href = "index.html";
    return;
  }

  currentUserUid = user.uid;
  noteOwnerUid = user.uid;

  // Dashboard info
  document.getElementById("studentName").textContent = user.displayName || "Student";
  document.getElementById("studentEmail").textContent = user.email;

  const savedPhoto = localStorage.getItem(`profilePhoto_${user.uid}`);
  profileImg.src = savedPhoto ? savedPhoto : "student.jpg";

  loadRating();
  setRatingPermission();
  loadNotes();
});
