// js/admin.js
import {
  auth,
  db,
  collection,
  getDocs,
  deleteDoc,
  doc,
  onAuthStateChanged,
  query,
  orderBy,
  getDoc
} from "./firebase.js";

const usersList = document.getElementById("usersList");
const qaList = document.getElementById("qaList");
const reportsList = document.getElementById("reportsList");
const notesList = document.getElementById("notesList");

/* ---------- AUTH CHECK ---------- */
onAuthStateChanged(auth, async user => {
  if (!user) return location.href = "index.html";

  const uDoc = await getDoc(doc(db, "users", user.uid));
  if (!uDoc.exists() || uDoc.data().role !== "admin") {
    alert("Admins only");
    return location.href = "home.html";
  }

  loadUsers();
  loadQA();
  loadReports();
  loadNotes();
});

/* ---------- USERS ---------- */
async function loadUsers() {
  usersList.innerHTML = "";
  const snap = await getDocs(collection(db, "users"));

  snap.forEach(d => {
    const u = d.data();
    const div = document.createElement("div");
    div.className = "card";
    div.innerHTML = `
      <p>${u.name} (${u.email})</p>
      <button class="danger">Block User</button>
    `;

    div.querySelector("button").onclick = async () => {
      if (!confirm("Block this user?")) return;
      await deleteDoc(doc(db, "users", d.id));
      alert("User blocked");
      loadUsers();
    };

    usersList.appendChild(div);
  });
}

/* ---------- Q & A ---------- */
async function loadQA() {
  qaList.innerHTML = "";
  const snap = await getDocs(query(collection(db, "questions"), orderBy("createdAt","desc")));

  snap.forEach(q => {
    const d = q.data();
    const div = document.createElement("div");
    div.className = "card";
    div.innerHTML = `
      <p><b>Q:</b> ${d.text}</p>
      <p><small>By ${d.createdBy.name}</small></p>
      <button class="danger">Delete Question</button>
    `;

    div.querySelector("button").onclick = async () => {
      if (!confirm("Delete question?")) return;
      await deleteDoc(doc(db, "questions", q.id));
      loadQA();
    };

    qaList.appendChild(div);
  });
}

/* ---------- REPORTS (FULL INFO + ACTIONS) ---------- */
async function loadReports() {
  reportsList.innerHTML = "";
  const snap = await getDocs(query(collection(db, "reports"), orderBy("createdAt","desc")));

  snap.forEach(r => {
    const d = r.data();
    const div = document.createElement("div");
    div.className = "card";

    div.innerHTML = `
      <p><b>Question:</b> ${d.questionText}</p>
      <p><b>Asked By:</b> ${d.reportedUserName}</p>
      <p><b>Reason:</b> ${d.reason}</p>

      <button class="danger blockBtn">Block User</button>
      <button class="danger deleteBtn">Delete Content</button>
      <button class="ok resolveBtn">Resolve</button>
    `;

    div.querySelector(".blockBtn").onclick = async () => {
      if (!confirm("Block user?")) return;
      await deleteDoc(doc(db, "users", d.reportedUserId));
      alert("User blocked");
    };

    div.querySelector(".deleteBtn").onclick = async () => {
      if (!confirm("Delete reported content?")) return;
      await deleteDoc(doc(db, "questions", d.questionId));
      alert("Content deleted");
    };

    div.querySelector(".resolveBtn").onclick = async () => {
      await deleteDoc(doc(db, "reports", r.id));
      loadReports();
    };

    reportsList.appendChild(div);
  });
}

/* ---------- NOTES (LOCAL STORAGE) ---------- */
function loadNotes() {
  notesList.innerHTML = "";

  for (let i = 0; i < localStorage.length; i++) {
    const key = localStorage.key(i);
    if (!key.startsWith("notes_")) continue;

    const uid = key.split("_")[1];
    const notes = JSON.parse(localStorage.getItem(key)) || [];

    notes.forEach((n, idx) => {
      const div = document.createElement("div");
      div.className = "card";
      div.innerHTML = `
        <p>${n.name} <small>(User: ${uid})</small></p>
        <button class="danger">Delete</button>
      `;

      div.querySelector("button").onclick = () => {
        if (!confirm("Delete note?")) return;
        notes.splice(idx, 1);
        localStorage.setItem(key, JSON.stringify(notes));
        loadNotes();
      };

      notesList.appendChild(div);
    });
  }
}
